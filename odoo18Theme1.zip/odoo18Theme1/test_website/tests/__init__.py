# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_controller_args
from . import test_custom_snippet
from . import test_error
from . import test_form
from . import test_fuzzy
from . import test_image_upload_progress
from . import test_is_multilang
from . import test_media
from . import test_menu
from . import test_multi_company
from . import test_page_manager
from . import test_page
from . import test_performance
from . import test_qweb
from . import test_redirect
from . import test_reset_views
from . import test_restricted_editor
from . import test_session
from . import test_settings
from . import test_views_during_module_operation
from . import test_website_controller_page
from . import test_website_page_properties
