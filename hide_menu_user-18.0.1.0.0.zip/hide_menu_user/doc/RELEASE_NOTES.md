## Module <hide_menu_user>

#### 04.10.2024
#### Version 18.0.1.0.0
#### ADD

- Initial commit for Hide Any Menu User Wise
